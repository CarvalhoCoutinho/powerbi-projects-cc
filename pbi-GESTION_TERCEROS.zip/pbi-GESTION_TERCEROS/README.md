📊 Informe de Power BI (Gestión Terceros.pbix)

📌 Descripción General: Informe de Gestión de Terceros

🎯 Objetivo del informe:

    Hacer un seguimiento del saldo(bajas y altas) de los clientes a los que se les ofrecen serivicios como legalitas, intratime, entre otros.

👥 Audiencia objetivo:

    El informe esta en Nivel 1 Operaciones.

🔗 Fuentes de Datos:

🌍 Origen de los datos:

    Los datos provienen de distintas BBDD que se encuentran en el servidor 192.168.3.106 de producción y algunos del 192.168.3.121.

🔄 Actualización de los datos:

    Aún está por definir la actualización de los informes junto con los desarrollos que se están haciendo en fabric.

📝 Detalles pertinentes:

    El informe muestra la evolución del saldo de los clientes a los que se les da el servicio de los colaboradores que tenemos en conversia (legalitas e intratime hasta los momentos).

🛠️ Transformaciones y Modelado:

Todo el desarrollo se está haciendo en fabric, de manera tal que el pbi se conecta a la capa oro de fabric donde ya se encuentra el modelo estrella con la información lista para armar el informe.

🔍 Consultas de Power Query:

    Transformaciones de formatos de algunos campos para poder establecer las relaciones entre tablas de hechos y tablas dimensionales.

🔗 Relaciones:

    Modelos de estrella y tablas complementarias
![Modelo Estrella Principal](aux_docs/imgs/Estrella_Principal.png)
![Modelos Estrella Secundarios](aux_docs/imgs/Estrellas_Secundarias.png)
![Tablas Complementarias](aux_docs/imgs/Tablas_Complementarias.png)

🔍 Filtros aplicados:

   Ninguno

⚠️ Consideraciones Especiales:

🤔 Limitaciones o Supuestos:

    No

📞 Contacto:

    Carlos carvalho carlos.carvalho@conversia.es